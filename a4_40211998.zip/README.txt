website link: https://users.encs.concordia.ca/~s_markis/A4/

for exercise 1, an error keeps appearing saying the execution of the script is not permitted. this only
happened once i hosted the website, I had no problems before that. The same error appears with the logout 
operation but i could not find how to fix it.