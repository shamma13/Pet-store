<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assignment 4</title>
</head>
<body>
    <div style= "width:100%; text-align:center; padding-top:50px">
        <b>SOEN 287 - Assignment 4</b>
        <br>
        <b>Shamma Markis</b>
        <br>
        <b>40211998</b>
        <br>
        <br>
        <a href="Exercise1.php">Exercise 1</a>
        <br>
        <br>
        <a href="numOfVisits.php">Exercise 2</a>
        <br>
        <br>
        <a href="main.php">Exercise 3</a>
    </div>
    
</body>
</html>