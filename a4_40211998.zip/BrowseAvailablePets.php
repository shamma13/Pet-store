<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Browse Available Pets</title>
    <link rel="stylesheet" href="mainpage.css">
    <link rel="stylesheet" href="BrowseAvailablePets.css">
    <script src="myScript.js"></script>

</head>
<body onload="startTime()">
    <div id="container">
    <?php include('../s_markis/directory/header.php'); ?>

    <div id="mySidenav">
        <a href="main.php">Home Page</a>
        <a href="BrowseAvailablePets.php">Browse Available Pets</a>
        <a href="find_a_pet_form.php">Find a dog/cat</a>
        <a href="DogCare.php">Dog Care</a>
        <a href="CatCare.php">Cat Care</a>
        <a href="login.php">Have a pet to give away</a>
        <a href="ContactUs.php">Contact Us</a>
        <a href="createAccount.php">Create an account</a>
    </div>

    <div class="content">
        
        <table>
            <tr>
                <td><img class ="browsePets" src="cat1.jpg" alt="">
                    <h2>LILIBETH</h2>
                    <p>1 yr old, Burmese cat, Cat-friendly, Not declawed</p>
                    <button type="submit">Interested</button>
                </td>
                <td><img class ="browsePets" src="cat2.jfif" alt="">
                    <h2>CLEOPATRA</h2>
                    <p>2 yr old, Ragdoll cat, Kid-friendly, Not cat-friendly, Not declawed, Small dog-friendly</p>
                    <button type="submit">Interested</button>
                </td>
                <td><img class ="browsePets" src="cat3.jpg" alt="">
                    <h2>HENRI</h2>
                    <p>6 month old, Birman cat, Declawed, Not cat-friendly, Not dog-friendly, Not kid-friendly</p>
                    <button type="submit">Interested</button>
                </td>
            </tr>
            <tr>
                <td><img class ="browsePets" src="cat4.jpg" alt="">
                    <h2>MILLIE</h2>
                    <p>2 yr old, Siamese cat, Cat-friendly, Not declawed, Not dog-friendly, Not kid-friendly</p>
                    <button type="submit">Interested</button>
                </td>
                <td><img class ="browsePets" src="dog1.jfif" alt="">
                    <h2>LEROY</h2>
                    <p>3 yr old, German Shepherd, For owner with experience, High energy, House mandatory, Not cat-friendly, Not dog-friendly</p>
                    <button type="submit">Interested</button> 
                </td>
                <td><img class ="browsePets" src="dog2.jpg" alt="">
                    <h2>PEBBLES</h2>
                    <p>2 yr old, Pormeranian dog,  For intermediate owner, High energy, House mandatory, Not cat-friendly, Not dog-friendly, Not kid-friendly</p>
                    <button type="submit">Interested</button> 
                </td>
            </tr>
            <tr>
                <td><img class ="browsePets" src="dog3.jfif" alt="">
                    <h2>EARL</h2>
                    <p>5 yr old, Mixed breed, Dog-friendly, For intermediate owner, High energy, House mandatory, Not cat-friendly, Teen-friendly</p>
                    <button type="submit">Interested</button>
                </td>
                <td><img class ="browsePets" src="A3/dog4.webp" alt="">
                    <h2>RUSTY</h2>
                    <p>3 yr old, Bulldog, Dog-friendly, For intermediate owner, High energy, House mandatory, Not cat-friendly, Teen-friendly</p>
                    <button type="submit">Interested</button>
                </td>
                <td><img class ="browsePets" src="A3/dog5.jpg" alt="">
                    <h2>GRIZZLY</h2>
                    <p>1 yr old, Bulldog, For intermediate owner, High energy, House mandatory, Not cat-friendly, Selective with dogs, Teen-friendly</p>
                    <button type="submit">Interested</button>
                </td>
            </tr>
        </table>
        
    </div>
</div>

    <footer>
        <p>We do not sell, rent or exchange any personal information collected from our supporters with any other organization or entity</p>
        <p>Copyright &copy; 2022 Raise the woof.</p>
    </footer>
</body>
</html>