<header>
        <a href="AdoptAPet.php"><img class="image" src="logo.png" alt=""></a>
        <div class="time" id="currentDate"></div><br><br><br><br><br><br>
        <div class="time" id="currentTime"></div>
    </header>